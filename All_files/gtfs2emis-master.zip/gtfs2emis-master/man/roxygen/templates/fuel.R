#' @param fuel character. Type of fuel: 'D' (Diesel),'G' (Gasoline), 'CNG' 
#'        (Compressed Natural Gas). Default is 'D'.
