#' @param reference_year numeric. Year of reference, in which the emissions
#' inventory is estimated. Default is 2020. Values between 2015 - 2022.
