#' @param as_list logical. If `TRUE` (default), the function returns the output
#' in a `list` format. If `FALSE`, the output is returned in a `data.table` 
#' format.
