library(testthat)
library(gtfs2emis)

test_check("gtfs2emis")
